#!/usr/bin/env r
args<-commandArgs(TRUE)
rb = read.table(args[1], header=T)
rb$sd = rb$sat_def-rb$rz_storage-rb$unsat_stor
rb$et = rb$evap+rb$trans
tmp = diff(rb$sd)
rb$sdiff= c(0, tmp)
tmp = diff(rb$snowpack)
rb$snowdiff= c(0, tmp)
tmp = diff(rb$litter_store)
rb$litdiff= c(0, tmp)
tmp = diff(rb$canopy_store)
rb$candiff= c(0, tmp)
tmp = diff(rb$detention_store)
rb$detdiff= c(0, tmp)
tmp = diff(rb$gw.storage)
rb$gwdiff= c(0, tmp)
rb$wb = rb$precip-rb$streamflow-rb$et-rb$detdiff-rb$candiff-rb$litdiff-rb$snowdiff+rb$sdiff-rb$gwdiff
nr = length(rb)
rb = rb[2:nr,]
