
To create CF9.1 reference DR5 flow table:

cf9.1 output=flow/DR5_cf91 template=templates/dr5_514_5m stream=streams road=roads_5m_bin dem=dem_5m slope=slope_5m cellsize=5

To create CF10 baseline (single surface, subsurface) flow table:

cf10.0a1 output=flow/DR5_cf10a1 template=templates/dr5_514_5m stream=streams road=roads_5m_bin dem=dem_5m slope=slope_5m cellsize=5



To create CF10 surface and subsurface flow tables using rooftop connectivity:

DR5:
cf10.0a1-test output=flow/DR5_cf10a1-test template=templates/dr5_514_5m stream=streams road=roads_5m_bin dem=dem_5m slope=slope_5m impervious=impervious_bin roof=rooftop_conn cellsize=5

Synthetic w/mask (r.mask cfmask maskcats 1):
cf10.0a1 output=flow/mask-synthetic template=templates/synthetic_514 stream=streams road=roads dem=dem slope=slope impervious=impervious roof=roofs cellsize=5

cf10.0a1 output=flow/mask-synthetic_clump template=templates/synthetic_514_clump stream=streams road=roads dem=dem slope=slope impervious=impervious roof=roofs cellsize=5

Synthetic w/mask, reference single flow table:
cf10.0a1 output=flow/mask-synthetic_single template=templates/synthetic_514 stream=streams road=roads dem=dem slope=slope cellsize=5

cf10.0a1 output=flow/mask-synthetic_clump_single template=templates/synthetic_514_clump stream=streams road=roads dem=dem slope=slope cellsize=5


Synthetic w/o mask:
cf10.0b1 output=flow/synthetic template=templates/synthetic_514 stream=streams road=roads dem=dem slope=slope impervious=impervious roof=roofs cellsize=5